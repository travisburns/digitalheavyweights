import React from 'react';
import { View, Text } from 'react-native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import MusicFeedScreen from '../screens/MusicFeedScreen';
import AddMusicScreen from '../components/AddMusicScreen';
import { StyleSheet } from 'react-native';
import ProfileScreen from '../screens/ProfileScreen';
import CommunityScreen from '../screens/CommunityScreen';
import { MaterialIcons } from '@expo/vector-icons';

const Tab = createBottomTabNavigator();

const AppNavigator = () => {
  return (
    <Tab.Navigator
      screenOptions={{
        tabBarStyle: styles.tabNavigation, // Change style to tabBarStyle
        tabBarActiveTintColor: 'teal', // Change the active icon color
        tabBarInactiveTintColor: 'white', // Change the inactive icon color
        headerShown: true, // Show the header
        headerTitle: () => ( // Set a consistent header title
          <Text style={styles.headerText}>musefind</Text>
        ),
        headerRight: () => ( // Add notification and message icons to the right
          <View style={styles.headerRight}>
            <MaterialIcons name='notifications' size={24} color='teal' style={styles.headerIcon} />
            <MaterialIcons name='message' size={24} color='teal' style={styles.headerIcon} />
          </View>
        ),
        headerStyle: { // Set the header background color
          backgroundColor: 'black',
        },
      }}
    >
      <Tab.Screen
        name='MusicFeed'
        component={MusicFeedScreen}
        options={{
          tabBarIcon: ({ color, size }) => (
            <MaterialIcons name='headset' size={size} color={color} />
          ),
          tabBarLabel: '', // Hide label
        }}
      />




<Tab.Screen
        name='AddMusic'
        component={AddMusicScreen}
        options={{
          tabBarIcon: ({ color, size }) => (
            <MaterialIcons name='headset' size={size} color={color} />
          ),
          tabBarLabel: '', // Hide label
        }}
      />


<Tab.Screen
        name='Profile'
        component={ProfileScreen}
        options={{
          tabBarIcon: ({ color, size }) => (
            <MaterialIcons name='person' size={size} color={color} />
          ),
          tabBarLabel: '', // Hide label
        }}
      />

<Tab.Screen
        name='Community'
        component={CommunityScreen}
        options={{
          tabBarIcon: ({ color, size }) => (
            <MaterialIcons name='people' size={size} color={color} />
          ),
          tabBarLabel: '', // Hide label
        }}
      />
      {/* ... other screens */}
    </Tab.Navigator>
  );
};

const styles = StyleSheet.create({
  tabNavigation: {
    backgroundColor: 'black',
  },
  headerText: {
    fontSize: 20,
    fontWeight: 'bold',
    color: 'white', // Adjust header text color as needed
  },
  headerRight: {
    flexDirection: 'row',
    marginRight: 10,
  },
  headerIcon: {
    marginLeft: 10,
  },
});

export default AppNavigator;