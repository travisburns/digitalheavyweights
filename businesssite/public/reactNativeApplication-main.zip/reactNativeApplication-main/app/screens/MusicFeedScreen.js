import React, { useState } from 'react';
import { View, Text, Button, FlatList, StyleSheet, TouchableOpacity, TextInput, Image, ScrollView } from 'react-native';
import { Audio } from 'expo-av';
import { Ionicons } from '@expo/vector-icons'; // Import Ionicons from @expo/vector-icons
import exampleImage from '../../assets/example.png';

const UserProfileWithStories = () => {
  const [stories, setStories] = useState([
    { id: '1', user: 'User 1', image: exampleImage },
    { id: '2', user: 'User 2', image: exampleImage },
    { id: '3', user: 'User 3', image: exampleImage },
    { id: '4', user: 'User 4', image: exampleImage },
    { id: '5', user: 'User 5', image: exampleImage },
    { id: '6', user: 'User 6', image: exampleImage },
    { id: '7', user: 'User 4', image: exampleImage },
    { id: '8', user: 'User 5', image: exampleImage },
    { id: '9', user: 'User 6', image: exampleImage },
    { id: '10', user: 'User 4', image: exampleImage },
    { id: '11', user: 'User 5', image: exampleImage },
    { id: '12', user: 'User 6', image: exampleImage },
    // Add more stories as needed
  ]);

  return (
    <View style={styles.userProfileWithStoriesContainer}>
      {stories.map(story => (
        <TouchableOpacity key={story.id} style={styles.storyContainer}>
          <Image source={story.image} style={styles.storyImage} />
          <Text style={styles.storyUser}>{story.user}</Text>
        </TouchableOpacity>
      ))}
    </View>
  );
};

const MusicFeedScreen = ({ navigation }) => {
  const [musicEntries, setMusicEntries] = useState([]);
  const [sound, setSound] = useState(null);
  const [searchQuery, setSearchQuery] = useState('');

  const playAudio = async (audioURI) => {
    if (sound) {
      await sound.unloadAsync();
    }

    const { sound: newSound } = await Audio.Sound.createAsync(
      { uri: audioURI },
      { shouldPlay: true }
    );

    setSound(newSound);
  };

  const wallPosts = [
    { id: '1', image: exampleImage },
    { id: '2', image: exampleImage },
    { id: '3', image: exampleImage },
    { id: '4', image: exampleImage },
    { id: '5', image: exampleImage },
    { id: '6', image: exampleImage },
    { id: '7', image: exampleImage },
    { id: '8', image: exampleImage },
    { id: '9', image: exampleImage },
    { id: '10', image: exampleImage },
    { id: '12', image: exampleImage },
    { id: '13', image: exampleImage },
  ];

  const addMusicEntry = (musicEntry) => {
    setMusicEntries([...musicEntries, musicEntry]);
  };

  const renderMusicEntries = () => {
    const filteredEntries = musicEntries.filter(entry =>
      entry.genre.toLowerCase().includes(searchQuery.toLowerCase())
    );

    return filteredEntries.map((entry, index) => (
      <TouchableOpacity
        key={index}
        style={styles.musicEntryContainer}
        onPress={() => playAudio(entry.selectedAudio.uri)}
      >
        <Text style={styles.musicEntryText}>Track Name: {entry.trackName}</Text>
        <Text style={styles.musicEntryText}>Artist Name: {entry.artistName}</Text>
        <Text style={styles.musicEntryText}>Genre: {entry.genre}</Text>
      </TouchableOpacity>
    ));
  };

  return (
    <View style={styles.container}>
    <ScrollView horizontal={true}>
    {/* User Profiles and Stories */}
    <UserProfileWithStories style={styles.userStories}/>
    </ScrollView>
      

      {/* Rest of the content */}
      

      <FlatList
        data={wallPosts}
        renderItem={({ item }) => (
          <TouchableOpacity style={styles.postItem}>
            {/* Top Section */}
            <View style={styles.topSection}>
              <Image source={exampleImage} style={styles.userImage} />
              <Text style={styles.username}>Username</Text>
            </View>

            {/* Image */}
            <Image source={item.image} style={styles.postImage} />
            
            {/* Bottom Section */}
            <View style={styles.postCaption}>
              <View style={styles.postButtons}>
                {/* Like Button */}
                <TouchableOpacity style={styles.button}>
                  <Ionicons name="heart-outline" size={24} color="white" />
                </TouchableOpacity>
                {/* Comment Button */}
                <TouchableOpacity style={styles.button}>
                  <Ionicons name="chatbubble-outline" size={24} color="white" />
                </TouchableOpacity>
                {/* Share Button */}
                <TouchableOpacity style={styles.button}>
                  <Ionicons name="share-outline" size={24} color="white" />
                </TouchableOpacity>
              </View>
              <Text style={styles.captionText}>Lorem epson text illusmion trevious ahdnf</Text>
              <View>
                <Text style={styles.commentsText}>45 Comments</Text>
                <Text style={styles.commentsViewMore}>View More...</Text>
              </View>
            </View>
          </TouchableOpacity>
        )}
        keyExtractor={item => item.id}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'black',
    padding: 10,
  },
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 20,
    paddingHorizontal: 20,
  },
  searchInput: {
    flex: 1,
    backgroundColor: 'white',
    marginRight: 10,
    padding: 10,
    borderRadius: 5,
    color: 'black',
  },
  userProfileWithStoriesContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 10,
  },
  storyContainer: {
    alignItems: 'center',
  },
  storyImage: {
    width: 90,
    height: 90,
    borderRadius: 50,
  },
  storyUser: {
    color: 'white',
    marginTop: 5,
  },
  topSection: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
  },
  userImage: {
    width: 30,
    height: 30,
    borderRadius: 15,
    marginRight: 10,
  },
  username: {
    color: 'white',
    fontSize: 16,
  },
  postItem: {
    flex: 1,
    aspectRatio: 1,
    margin: 1,
    marginVertical: 20,
    height: 500
  },
  postImage: {
    flex: 1,
  },
  postText: {
    color: 'white',
    fontSize: 15
  },
  postButtons: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  button: {
    marginRight: 10,
  },

  postCaption: {
    width: '100%',
    
    backgroundColor: 'teal'
  },

  captionText: {
    fontSize: 13,
    color: 'white'
  },

  commentsText: {
    color: 'white',
    fontSize: 10
  },
  commentsViewMore: {
    color: 'white',
    fontSize: 10
  },
});

export default MusicFeedScreen;