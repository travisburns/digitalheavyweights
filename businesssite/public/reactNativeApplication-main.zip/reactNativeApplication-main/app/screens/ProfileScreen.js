import React from 'react';
import { View, Text, StyleSheet, Image, ScrollView, Dimensions, TouchableOpacity } from 'react-native';
import { Feather } from '@expo/vector-icons';

// Import your images properly
import exampleImage from '../../assets/example.png';
import userProfile from '../../assets/userProfile.png';

const ProfileScreen = () => {
  // Dummy data for user posts
  const userPosts = [
    { id: '1', image: exampleImage },
    { id: '2', image: exampleImage },
    { id: '3', image: exampleImage },
    { id: '4', image: exampleImage },
    { id: '5', image: exampleImage },
    { id: '6', image: exampleImage },
    { id: '7', image: exampleImage },
    { id: '8', image: exampleImage },
    { id: '9', image: exampleImage },
    { id: '10', image: exampleImage },
    { id: '12', image: exampleImage },
    { id: '13', image: exampleImage },
    // Add more posts as needed
  ];




  // Calculate the width of each post item
  const screenWidth = Dimensions.get('window').width;
  const numColumns = 3; // Adjust as needed
  const postItemWidth = (screenWidth - 40) / numColumns; // 40 is the total horizontal padding
  return (
    <View style={styles.container}>
      <View style >
      <Text style={styles.header}>User Profile</Text>
      <View style={styles.profileInfo}>
        <View style={styles.profileHeader}>
          <Image source={userProfile} style={styles.userImage} />
          <View style={styles.usernameContainer}>
            <Text style={styles.label}>Username:</Text>
            <Text style={styles.value}>example_user</Text>
          </View>
          <View style={styles.statsContainer}>
          <View>
          <Text style={styles.statNumber}>10000</Text>
          <Text style={styles.text}>reputation</Text>
          </View>
          
          <View>
          <Text style={styles.statNumber}>10000</Text>
          <Text style={styles.text}>followers</Text>
          </View>
          <View>
          <Text style={styles.statNumber}>10000</Text>
          <Text style={styles.text}>friends</Text>
          </View>

          </View>
        </View>
      </View>
     
      </View>
     
      <View style={styles.profileInfo}>
        <Text style={styles.label}>Bio:</Text>
        <Text style={styles.value}>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</Text>
      </View>
      {/* Section for displaying recent contributions */}
      <View style={styles.contributionsContainer}>
        <Text style={styles.sectionHeader}>Recent Contributions</Text>
        <View style={styles.contributions}>
          {/* Render recent contributions icons */}
          <Feather name="activity" size={24} color="white" />
          <Feather name="award" size={24} color="white" />
          <Feather name="heart" size={24} color="white" />
          <Feather name="star" size={24} color="white" />
          <Feather name="trending-up" size={24} color="white" />
        </View>
      </View>

    



      {/* Separator Line */}
      <View style={styles.separatorLine} />
      <ScrollView horizontal={true} contentContainerStyle={styles.postButtonsContainer}>
      <TouchableOpacity style={styles.postsButton}>
      <Text style={styles.postText}>Posts</Text>
      </TouchableOpacity>
      <TouchableOpacity style={styles.postsButton}>
      <Text style={styles.postText}>Reels</Text>
      </TouchableOpacity>
      <TouchableOpacity style={styles.postsButton}>
      <Text style={styles.postText}>Tagged</Text>
      </TouchableOpacity>
      </ScrollView>
     
      <ScrollView>
        <View style={styles.userPosts}>
          {userPosts.map(post => (
            <View key={post.id} style={[styles.postItem, { width: postItemWidth }]}>
              <Image source={post.image} style={styles.postImage} />
            </View>
          ))}
        </View>
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'black',
    padding: 10,
    
  },
  flex: {
    flex: 1,
    flexDirection: 'row'
  },

  text: {
    fontSize: 13,
    color: 'white'
  },

  statNumber: {
    fontSize: 20,
    color: 'white'
  },

  header: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
    color: 'white',
  },
  profileInfo: {
    marginBottom: 10,
  },
  profileHeader: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  usernameContainer: {
    marginLeft: 10,
    marginRight: 15,
  },


  statsContainer: {
    flex:1,
    flexDirection: 'row'
  },

  label: {
    fontSize: 18,
    color: 'white',
  },
  value: {
    fontSize: 16,
    color: 'lightgrey',
  },
  sectionHeader: {
    fontSize: 20,
    fontWeight: 'bold',
    color: 'white',
    marginTop: 20,
    marginBottom: 10,
  },
  contributionsContainer: {},
  contributions: {
    paddingVertical: 20,
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  separatorLine: { // Styles for the separator line
    height: 1, // Set the height of the line
    backgroundColor: '#e0e0e0', // Example border color
  },
  postText: {
    color: 'white',
    fontSize: 20,
    fontWeight: 'bold',
    height: 100,
    textAlign: 'center'
  },

  postButtonsContainer: { // Keep this style for layout
    marginVertical: 10,
    flexDirection: 'row',
    justifyContent: 'space-around', // Distribute buttons evenly
   
    
  },


  postButtons: {
    marginBottom: 20,
    
  },


  postsButton: {
    marginVertical: 10,
    backgroundColor: 'teal',
    width: 110,
    marginHorizontal: 12,
    borderRadius: 5
  },

  userPosts: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    margin: 0,
    padding: 0,
    
  },
  postItem: {
    marginVertical: 0, // Remove margin
    borderRadius: 5,
    overflow: 'hidden',
    backgroundColor: 'blue',
    
    
  },
  postImage: {
    width: 180, // Set a specific width
    height: 120,
    resizeMode: 'cover',
    backgroundColor: 'blue'
  },
  userImage: {
    height: 50,
    width: 50,
    borderRadius: 25,
  },
});

export default ProfileScreen;