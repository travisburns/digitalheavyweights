import React, { useState, useContext } from 'react';
import { View, Text, Button, TextInput, StyleSheet } from 'react-native';
import RNPickerSelect from 'react-native-picker-select';
import { AudioContext } from '../context/AudioProvider';

//The addMusicScreen will have the parameters of navigation, and route passed. as navigation is used below to automatically go back to musicfeed screen. and route is for the musicentry data below.
const AddMusicScreen = ({ navigation, route }) => {
  //hooks for the audiofiles textinputs
  //the audioFiles actually uses useContext to pass the values from the AudioProvider, Felt useContext was easier than prop drilling. 
  const { audioFiles } = useContext(AudioContext);
  const [selectedAudio, setSelectedAudio] = useState(null);
  const [trackName, setTrackName] = useState('');
  const [artistName, setArtistName] = useState('');
  const [genre, setGenre] = useState('');

  // function control the submit once button is pressed. It contains the keys of trackName, artistName, Genre, and SelectedAudio. 
  const handleSubmit = () => {
    const musicEntry = {
      trackName: trackName,
      artistName: artistName,
      genre: genre,
      selectedAudio: selectedAudio,
    };
    // Call the addMusicEntry function passed via route params to add the music entry
    //if the routes params and routes params at addmusic Entry is true then route params should attach the values from musicEntry to addMusic Entry. 
    //in this case the route params and route params addMusicEntry will allways be true if submitted. 
    if (route.params && route.params.addMusicEntry) {
      route.params.addMusicEntry(musicEntry);
    }
    // Navigate back to the MusicFeedScreen
    //On default after submitted the form. It will just default back to the music feed screen. 
    navigation.goBack();
  };
//picker items is equal to the audoFiles that are attached to the useContext from AudioContext, within the audioFiles, it should map the parameter of audio the keys of label and value. with
//label having the audio's filename, and value having the audio parameter itself. 

  const pickerItems = audioFiles.map((audio) => ({
    label: audio.filename,
    value: audio,
  }));
 //below is the basic form and its values per text input, the values have their specific hooks attached to them. 
  //needed a way to select a variety of different selections in a dropdown. I found RNPicker to be a great choice for this on looking through google. defined below.

  return (
    <View style={styles.container}>
      <Text style={styles.header}>Add Music</Text>
      <TextInput
        style={styles.input}
        placeholder="Track Name"
        value={trackName}
        onChangeText={setTrackName}
      />
      <TextInput
        style={styles.input}
        placeholder="Artist Name"
        value={artistName}
        onChangeText={setArtistName}
      />
      <TextInput
        style={styles.input}
        placeholder="Genre"
        value={genre}
        onChangeText={setGenre}
      />
      <RNPickerSelect
        style={pickerSelectStyles}
        placeholder={{ label: 'Select Audio File', value: null }}
        items={pickerItems}
        onValueChange={(value) => setSelectedAudio(value)}
      />
      <Button title="Submit" onPress={handleSubmit} color="green" />
    </View>
  );
};
// found out through reading through RNPickers documentation, that you cant use a basic styling in react for it style, you have to use a additional style with either inputIOS, or inputAndroid. 
const pickerSelectStyles = StyleSheet.create({
  inputIOS: {
    backgroundColor: 'white',
    marginBottom: 10,
    padding: 10,
    borderRadius: 5,
    color: 'white',
  },
  inputAndroid: {
    backgroundColor: 'white',
    marginBottom: 10,
    padding: 10,
    borderRadius: 5,
    color: 'white',
  },
});

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'black',
    padding: 20,
  },
  header: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
    color: 'white',
    textAlign: 'center',
  },
  input: {
    backgroundColor: 'white',
    marginBottom: 10,
    padding: 10,
    borderRadius: 5,
    color: 'black', 
  },
});

export default AddMusicScreen;